<?php
//
// New API utils and classes for Nagios XI 5
// Copyright (c) 2020 Nagios Enterprises, LLC. All rights reserved.
//

