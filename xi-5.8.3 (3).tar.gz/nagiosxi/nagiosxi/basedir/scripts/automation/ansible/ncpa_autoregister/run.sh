#!/bin/bash
ansible-playbook ncpa_install_and_register.yml --ask-vault-pass
